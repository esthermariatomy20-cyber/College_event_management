from django.urls import path
from . import views


urlpatterns = [

    path(
        "dashboard/",
        views.dashboard,
        name="admin_dashboard"
    ),

    path(
        "events/",
        views.events,
        name="admin_events"
    ),

    path(
        "events/add/",
        views.add_event,
        name="add_event"
    ),

    path(
        "events/edit/<int:event_id>/",
        views.edit_event,
        name="edit_event"
    ),

    path(
        "events/delete/<int:event_id>/",
        views.delete_event,
        name="delete_event"
    ),

    path(
        "students/",
        views.students,
        name="admin_students"
    ),

    path(
        "registrations/",
        views.registrations,
        name="admin_registrations"
    ),

]