from django.shortcuts import render

# Create your views here.
from django.shortcuts import (
    render,
    redirect,
    get_object_or_404
)

from .models import Event
from student.models import Student, Registration


def dashboard(request):

    total_events = Event.objects.count()

    published_events = Event.objects.filter(
        is_published=True
    ).count()

    total_students = Student.objects.count()

    total_registrations = Registration.objects.count()

    context = {
        "total_events": total_events,
        "published_events": published_events,
        "total_students": total_students,
        "total_registrations": total_registrations,
    }

    return render(
        request,
        "admin/dashboard.html",
        context
    )


def events(request):

    events_list = Event.objects.all()

    return render(
        request,
        "admin/events.html",
        {
            "events": events_list
        }
    )


def add_event(request):

    if request.method == "POST":

        Event.objects.create(

            title=request.POST.get("title"),

            category=request.POST.get(
                "category"
            ),

            description=request.POST.get(
                "description"
            ),

            date=request.POST.get("date"),

            time=request.POST.get("time"),

            venue=request.POST.get("venue"),

            participant_limit=request.POST.get(
                "participant_limit"
            ),

            organizer=request.POST.get(
                "organizer"
            ),

            rules=request.POST.get(
                "rules"
            ),

            is_published=True
        )

        return redirect(
            "admin_events"
        )

    return render(
        request,
        "admin/add_event.html"
    )


def edit_event(request, event_id):

    event = get_object_or_404(
        Event,
        id=event_id
    )

    if request.method == "POST":

        event.title = request.POST.get(
            "title"
        )

        event.category = request.POST.get(
            "category"
        )

        event.description = request.POST.get(
            "description"
        )

        event.date = request.POST.get(
            "date"
        )

        event.time = request.POST.get(
            "time"
        )

        event.venue = request.POST.get(
            "venue"
        )

        event.participant_limit = request.POST.get(
            "participant_limit"
        )

        event.organizer = request.POST.get(
            "organizer"
        )

        event.rules = request.POST.get(
            "rules"
        )

        event.save()

        return redirect(
            "admin_events"
        )

    return render(
        request,
        "admin/edit_event.html",
        {
            "event": event
        }
    )


def delete_event(request, event_id):

    event = get_object_or_404(
        Event,
        id=event_id
    )

    if request.method == "POST":

        event.delete()

    return redirect(
        "admin_events"
    )


def students(request):

    students_list = Student.objects.all()

    return render(
        request,
        "admin/students.html",
        {
            "students": students_list
        }
    )


def registrations(request):

    registrations_list = Registration.objects.select_related(
        "student",
        "event"
    )

    return render(
        request,
        "admin/registrations.html",
        {
            "registrations": registrations_list
        }
    )