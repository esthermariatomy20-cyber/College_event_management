from django.db import models

# Create your models here.
from django.db import models


class Event(models.Model):

    CATEGORY_CHOICES = [
        ("technical", "Technical"),
        ("cultural", "Cultural"),
        ("sports", "Sports"),
        ("workshop", "Workshop"),
        ("other", "Other"),
    ]

    title = models.CharField(
        max_length=200
    )

    category = models.CharField(
        max_length=30,
        choices=CATEGORY_CHOICES
    )

    description = models.TextField()

    date = models.DateField()

    time = models.TimeField()

    venue = models.CharField(
        max_length=200
    )

    participant_limit = models.PositiveIntegerField(
        default=100
    )

    registration_deadline = models.DateTimeField(
        null=True,
        blank=True
    )

    image = models.ImageField(
        upload_to="events/",
        null=True,
        blank=True
    )

    rules = models.TextField(
        blank=True
    )

    organizer = models.CharField(
        max_length=200,
        blank=True
    )

    is_published = models.BooleanField(
        default=False
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    updated_at = models.DateTimeField(
        auto_now=True
    )


    class Meta:
        ordering = ["date", "time"]


    def __str__(self):
        return self.title


    @property
    def registration_count(self):

        return self.registrations.count()


    @property
    def seats_remaining(self):

        return max(
            self.participant_limit -
            self.registration_count,
            0
        )