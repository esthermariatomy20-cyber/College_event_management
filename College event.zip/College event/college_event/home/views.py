from django.shortcuts import render
from .models import Announcement


def home(request):

    announcements = Announcement.objects.filter(
        is_active=True
    )

    return render(
        request,
        "home/home.html",
        {
            "announcements": announcements
        }
    )