from django.urls import path
from . import views


urlpatterns = [

    path(
        "dashboard/",
        views.dashboard,
        name="student_dashboard"
    ),

    path(
        "events/",
        views.events,
        name="student_events"
    ),

    path(
        "event/<int:event_id>/",
        views.event_detail,
        name="event_detail"
    ),

    path(
        "event/<int:event_id>/register/",
        views.register_event,
        name="register_event"
    ),

    path(
        "my-events/",
        views.my_events,
        name="my_events"
    ),

]