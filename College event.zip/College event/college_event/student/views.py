from django.shortcuts import render

# Create your views here.
from django.shortcuts import (
    render,
    get_object_or_404,
    redirect
)

from django.contrib import messages

from .models import Student, Registration
from admin.models import Event


def dashboard(request):

    # Temporary student
    student = Student.objects.first()

    registrations = []

    if student:

        registrations = Registration.objects.filter(
            student=student,
            status="registered"
        ).select_related("event")

    return render(
        request,
        "student/dashboard.html",
        {
            "student": student,
            "registrations": registrations
        }
    )


def events(request):

    events_list = Event.objects.filter(
        is_published=True
    )

    category = request.GET.get(
        "category"
    )

    search = request.GET.get(
        "search"
    )

    if category:

        events_list = events_list.filter(
            category=category
        )

    if search:

        events_list = events_list.filter(
            title__icontains=search
        )

    return render(
        request,
        "student/events.html",
        {
            "events": events_list
        }
    )


def event_detail(request, event_id):

    event = get_object_or_404(
        Event,
        id=event_id,
        is_published=True
    )

    return render(
        request,
        "student/event_detail.html",
        {
            "event": event
        }
    )


def register_event(request, event_id):

    event = get_object_or_404(
        Event,
        id=event_id,
        is_published=True
    )

    # Temporary student
    student = Student.objects.first()

    if not student:

        messages.error(
            request,
            "Student profile not found."
        )

        return redirect(
            "student_events"
        )

    if event.seats_remaining <= 0:

        messages.error(
            request,
            "This event is full."
        )

        return redirect(
            "event_detail",
            event_id=event.id
        )

    registration, created = Registration.objects.get_or_create(

        student=student,

        event=event,

        defaults={
            "status": "registered"
        }
    )

    if created:

        messages.success(
            request,
            "Successfully registered!"
        )

    else:

        messages.info(
            request,
            "You are already registered."
        )

    return redirect(
        "my_events"
    )


def my_events(request):

    student = Student.objects.first()

    registrations = []

    if student:

        registrations = Registration.objects.filter(
            student=student
        ).select_related(
            "event"
        )

    return render(
        request,
        "student/my_events.html",
        {
            "student": student,
            "registrations": registrations
        }
    )