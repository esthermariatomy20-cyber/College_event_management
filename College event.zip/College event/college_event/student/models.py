from django.db import models

# Create your models here.
from django.db import models
from admin.models import Event


class Student(models.Model):

    YEAR_CHOICES = [
        (1, "First Year"),
        (2, "Second Year"),
        (3, "Third Year"),
        (4, "Fourth Year"),
    ]

    name = models.CharField(
        max_length=150
    )

    student_id = models.CharField(
        max_length=50,
        unique=True
    )

    email = models.EmailField(
        unique=True
    )

    department = models.CharField(
        max_length=100
    )

    year = models.PositiveIntegerField(
        choices=YEAR_CHOICES
    )

    phone = models.CharField(
        max_length=15,
        blank=True
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )


    def __str__(self):
        return f"{self.name} ({self.student_id})"


class Registration(models.Model):

    STATUS_CHOICES = [
        ("registered", "Registered"),
        ("cancelled", "Cancelled"),
        ("attended", "Attended"),
    ]

    student = models.ForeignKey(
        Student,
        on_delete=models.CASCADE,
        related_name="registrations"
    )

    event = models.ForeignKey(
        Event,
        on_delete=models.CASCADE,
        related_name="registrations"
    )

    registered_at = models.DateTimeField(
        auto_now_add=True
    )

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="registered"
    )


    class Meta:

        constraints = [
            models.UniqueConstraint(
                fields=["student", "event"],
                name="unique_student_event"
            )
        ]

        ordering = ["-registered_at"]


    def __str__(self):

        return (
            f"{self.student.name} - "
            f"{self.event.title}"
        )